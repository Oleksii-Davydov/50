import './App.css';
import ClippedDrawer from "./components/drower/Drower";

function App() {
    return (
        <div className="App">
            <ClippedDrawer/>
        </div>
    );
}

export default App;
